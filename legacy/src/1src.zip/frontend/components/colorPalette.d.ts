export const CLARITY_COLORS: {
    amber: string;
    mandarine: string;
    neonOrange: string;
    deepRuby: string;
    rubyHighlight: string;
    rubyShadow: string;
    darkBlue: string;
    electricBlue: string;
    black: string;
    darkGray: string;
    mediumGray: string;
    lightGray: string;
    white: string;
};
